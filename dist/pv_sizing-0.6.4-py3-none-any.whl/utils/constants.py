import numpy as np

# Eficiencia media mensual. Valores estándar.
fresnel_fixed = np.array([0.948, 0.926, 0.913, 0.898, 0.914, 0.886, 0.883, 0.902, 0.887, 0.934, 0.937, 0.944])
